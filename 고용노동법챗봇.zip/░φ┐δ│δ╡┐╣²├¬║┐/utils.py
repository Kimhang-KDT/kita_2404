from openai import OpenAI
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.docstore.document import Document
from model import get_all_contents
import os
from config import OPENAI_API_KEY

os.environ['OPENAI_API_KEY'] = OPENAI_API_KEY

VECTORSTORE_PATH = "vectorstore.faiss"

def initialize_vectorstore():
    sections = get_all_contents()
    documents = [Document(page_content=section) for section in sections]

    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_documents(documents, embeddings)

    vectorstore.save_local(VECTORSTORE_PATH)
    return vectorstore

def set_prompt(user_input):
    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.load_local(VECTORSTORE_PATH, embeddings, allow_dangerous_deserialization=True)

    retriever = vectorstore.as_retriever(search_kwargs={'k':5})
    
    relevant_documents = retriever.invoke(user_input)
    relevant_sections = "\n".join([doc.page_content for doc in relevant_documents])

    sys_prompt = (
        "당신은 한국의 공인 노무사입니다.\n\n"
        f"{relevant_sections}\n\n"
        "사용자의 질문에 대해 정확하고 명확하게, 부드러운 어조로 답변합니다.\n\n"
    )

    return sys_prompt

def get_ai_response(user_input):
    # 벡터 저장소 초기화 시에만 호출
    #initialize_vectorstore()

    # 프롬프트 생성
    sys_prompt = set_prompt(user_input)

    # OpenAI API 호출
    client = OpenAI(api_key=OPENAI_API_KEY)
    completion = client.chat.completions.create(
        model='gpt-4o-mini-2024-07-18',
        messages=[
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": user_input},
        ]
    )

    # 응답에서 텍스트만 추출
    return completion.choices[0].message.content