from flask import Flask, render_template, request, jsonify
from utils import *

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat')
def chat():
    return render_template('chat.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    # 유저가 보낸 메시지를 받음
    user_input = request.json.get("message")
    
    # 여기서 OpenAI API 등을 사용해 AI 응답을 생성할 수 있습니다.
    # 예시로 간단한 응답을 생성:
    ai_response = get_ai_response(user_input)
    
    # JSON 형태로 응답을 반환
    return jsonify({"response": ai_response})

if __name__ == "__main__":
    app.run(debug=True)
